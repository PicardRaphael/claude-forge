---
name: schema-data-source
description: Guide to read PostgreSQL tables from CSV (doc/dump/) and functions from the SQL repo. Two separate sources. No DB connection required.
user-invokable: false
---

# Sources de données

## Source 1 — Tables (fichiers CSV dans `doc/dump/`)

Exportées via `scripts/export-schema.sh`. Aucune connexion BDD après export.

| Fichier | Contenu | Colonnes |
|---------|---------|----------|
| `schemas.csv` | Schémas | schema_name |
| `tables.csv` | Tables | table_schema, table_name |
| `fk.csv` | Foreign keys | source_schema, source_table, source_column, target_schema, target_table, target_column |
| `columns.csv` | Colonnes | table_schema, table_name, column_name, data_type, is_nullable, column_default, ordinal_position |
| `indexes.csv` | Indexes uniques | schema_name, table_name, index_name, columns, is_unique |
| `triggers.csv` | Triggers → tables | trigger_schema, trigger_name, event, table_schema, table_name, timing, action_statement |

## Source 2 — Fonctions (repo SQL séparé)

Le chemin du repo est donné par l'utilisateur. Structure :

```
repo-functions/
  {schema}/              ← un dossier par schéma PostgreSQL
    f_*.sql              ← lecture (SELECT)
    p_*.sql              ← écriture (INSERT/UPDATE/DELETE)
    proc_*.sql           ← procédures stockées
    tr_*.sql             ← fonctions de trigger
```

**Les dossiers = les schémas PostgreSQL = des domaines métier potentiels.**

## Conventions de nommage

| Préfixe | Rôle | Opérations typiques |
|---------|------|---------------------|
| `f_*` | Lecture | SELECT, RETURN QUERY |
| `p_*` | Écriture | INSERT, UPDATE, DELETE |
| `proc_*` | Procédure | Orchestration, multi-étapes |
| `tr_*` | Trigger | BEFORE/AFTER sur événements table |

## Stratégie de lecture

### Tables (CSV)

**Ne JAMAIS lire `columns.csv` en entier.**

Ordre :
1. `schemas.csv` → schémas
2. `tables.csv` → toutes les tables
3. `fk.csv` → graphe de relations
4. `triggers.csv` → mapping trigger → table
5. `indexes.csv` → contraintes
6. `columns.csv` → Grep par cluster uniquement

### Fonctions (repo)

Ordre :
1. Glob `{repo}/**/*.sql` → inventaire complet (noms + chemins)
2. Compter par dossier/convention → stats
3. Lire le source seulement pour les fonctions d'un domaine en cours d'analyse

### Analyser les dépendances entre fonctions

Dans le source d'une fonction, chercher :
- Appels d'autres fonctions : `Grep pattern="f_\w+|p_\w+|proc_\w+" path="{fichier}.sql"`
- Tables référencées : `Grep pattern="FROM\s+\w+|JOIN\s+\w+|INTO\s+\w+|UPDATE\s+\w+|DELETE\s+FROM\s+\w+" path="{fichier}.sql"`

### Corréler fonctions et tables

Pour chaque domaine :
1. Le dossier du repo = le schéma = un domaine probable
2. Grep les noms de tables de ce domaine dans les fichiers SQL du dossier
3. Vérifier que les triggers de `triggers.csv` correspondent bien aux `tr_*.sql` du dossier

## Si les fichiers n'existent pas

STOP et afficher :

```
Les fichiers CSV n'existent pas dans doc/dump/.

Un dev doit exécuter :

  cp .claude/skills/schema-data-source/scripts/export-schema.sh .
  chmod +x export-schema.sh
  ./export-schema.sh "postgresql://USER:PASS@HOST:5432/DB"

Les fonctions sont lues directement depuis le repo SQL.
Précisez le chemin du repo : "Analyse ma BDD, le repo des fonctions est à /path/to/repo-functions"
```
